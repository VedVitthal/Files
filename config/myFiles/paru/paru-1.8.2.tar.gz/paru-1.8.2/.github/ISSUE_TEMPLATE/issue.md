---
name: Issue
about: Report an Issue
title: ''
labels: ''
assignees: ''

---

### Affected Version
**paru -V**

### Description
**Have you checked previous issues?**

### Output
**Include the FULL output of any relevant commands/configs**

**Don't cut parts of the input always include the FULL thing**

**paru.conf and pacman.conf are usually always relevant**

```sh

```
